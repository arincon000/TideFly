import { Button } from "@/components/ui/button";
import { Waves } from "lucide-react";

interface HeaderProps {
  isLoggedIn: boolean;
  onLoginClick: () => void;
  onSignOutClick: () => void;
}

export function Header({ isLoggedIn, onLoginClick, onSignOutClick }: HeaderProps) {
  return (
    <header className="w-full border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-ocean rounded-lg flex items-center justify-center">
              <Waves className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-foreground">TideFly</span>
          </div>

          {/* Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#features" className="text-muted-foreground hover:text-foreground transition-colors">
              Features
            </a>
            <a href="#pricing" className="text-muted-foreground hover:text-foreground transition-colors">
              Pricing
            </a>
            <a href="#how-it-works" className="text-muted-foreground hover:text-foreground transition-colors">
              How it works
            </a>
          </nav>

          {/* Auth buttons */}
          <div className="flex items-center space-x-3">
            {isLoggedIn ? (
              <>
                <Button variant="ghost" size="sm">
                  Dashboard
                </Button>
                <Button variant="outline" size="sm" onClick={onSignOutClick}>
                  Sign out
                </Button>
              </>
            ) : (
              <>
                <Button variant="ghost" size="sm" onClick={onLoginClick}>
                  Sign in
                </Button>
                <Button size="sm" className="bg-gradient-ocean hover:opacity-90 transition-opacity">
                  Get started
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}