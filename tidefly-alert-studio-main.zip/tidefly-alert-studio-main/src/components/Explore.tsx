import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";

// Fix for default markers in Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

interface SurfSpot {
  id: string;
  name: string;
  coordinates: [number, number];
  waveHeight: string;
  windSpeed: string;
  rating: number;
}

const surfSpots: SurfSpot[] = [
  { id: '1', name: 'Mundaka', coordinates: [43.4074, -2.7019], waveHeight: '1.2m', windSpeed: '15 km/h', rating: 4.8 },
  { id: '2', name: 'Ericeira', coordinates: [38.9631, -9.4158], waveHeight: '0.8m', windSpeed: '12 km/h', rating: 4.5 },
  { id: '3', name: 'Taghazout', coordinates: [30.5420, -9.7084], waveHeight: '1.5m', windSpeed: '18 km/h', rating: 4.7 },
  { id: '4', name: 'Peniche', coordinates: [39.3558, -9.3811], waveHeight: '1.0m', windSpeed: '14 km/h', rating: 4.3 },
  { id: '5', name: 'Hossegor', coordinates: [43.6614, -1.3976], waveHeight: '1.3m', windSpeed: '16 km/h', rating: 4.6 },
  { id: '6', name: 'Zarautz', coordinates: [43.2833, -2.1660], waveHeight: '0.9m', windSpeed: '13 km/h', rating: 4.2 },
  { id: '7', name: 'Nazaré', coordinates: [39.6011, -9.0714], waveHeight: '2.1m', windSpeed: '20 km/h', rating: 4.9 },
  { id: '8', name: 'Sopelana', coordinates: [43.3833, -2.9833], waveHeight: '1.1m', windSpeed: '15 km/h', rating: 4.1 },
];

interface ExploreProps {
  onBack: () => void;
}

export function Explore({ onBack }: ExploreProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<L.Map | null>(null);
  const markersRef = useRef<L.Marker[]>([]);
  const [selectedSpot, setSelectedSpot] = useState<SurfSpot | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredSpots = surfSpots.filter(spot =>
    spot.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  useEffect(() => {
    if (!mapContainer.current) return;

    // Initialize map
    map.current = L.map(mapContainer.current).setView([40.0, -4.0], 6);

    // Add OpenStreetMap tiles
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      maxZoom: 19,
    }).addTo(map.current);

    // Add surf spots to map
    surfSpots.forEach((spot) => {
      // Create custom icon
      const customIcon = L.divIcon({
        className: 'custom-surf-marker',
        html: `
          <div style="
            background: hsl(var(--primary));
            border: 3px solid hsl(var(--background));
            border-radius: 50%;
            width: 24px;
            height: 24px;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
          ">
            <div style="
              background: hsl(var(--background));
              border-radius: 50%;
              width: 8px;
              height: 8px;
            "></div>
          </div>
        `,
        iconSize: [24, 24],
        iconAnchor: [12, 12],
      });

      // Create marker
      const marker = L.marker(spot.coordinates, { icon: customIcon })
        .addTo(map.current!);

      // Create popup content
      const popupContent = `
        <div style="
          background: hsl(var(--card));
          border: 1px solid hsl(var(--border));
          border-radius: 8px;
          padding: 12px;
          color: hsl(var(--card-foreground));
          font-family: inherit;
          min-width: 180px;
          margin: -8px;
        ">
          <h3 style="margin: 0 0 8px 0; font-size: 16px; font-weight: 600;">${spot.name}</h3>
          <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
            <span style="color: hsl(var(--muted-foreground));">Wave Height:</span>
            <span style="font-weight: 500;">${spot.waveHeight}</span>
          </div>
          <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
            <span style="color: hsl(var(--muted-foreground));">Wind Speed:</span>
            <span style="font-weight: 500;">${spot.windSpeed}</span>
          </div>
          <div style="display: flex; justify-content: space-between;">
            <span style="color: hsl(var(--muted-foreground));">Rating:</span>
            <span style="font-weight: 500;">⭐ ${spot.rating}</span>
          </div>
        </div>
      `;

      marker.bindPopup(popupContent);

      // Add click event
      marker.on('click', () => {
        setSelectedSpot(spot);
      });

      markersRef.current.push(marker);
    });

    return () => {
      if (map.current) {
        map.current.remove();
        map.current = null;
        markersRef.current = [];
      }
    };
  }, []);

  const handleSpotClick = (spot: SurfSpot) => {
    if (map.current) {
      map.current.flyTo(spot.coordinates, 12, {
        duration: 1.5
      });
      setSelectedSpot(spot);
      
      // Open popup for this marker
      const marker = markersRef.current.find((m, index) => 
        surfSpots[index].id === spot.id
      );
      if (marker) {
        marker.openPopup();
      }
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={onBack}
                className="text-primary hover:text-primary-hover transition-colors"
              >
                ← Back
              </button>
              <h1 className="text-2xl font-bold">Explore Surf Spots</h1>
            </div>
            <div className="relative max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search surf spots..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="flex h-[calc(100vh-80px)]">
        {/* Sidebar */}
        <div className="w-80 border-r bg-card/30 overflow-y-auto">
          <div className="p-4 space-y-3">
            {filteredSpots.map((spot) => (
              <Card
                key={spot.id}
                className={`p-4 cursor-pointer transition-all hover:shadow-md ${
                  selectedSpot?.id === spot.id ? 'ring-2 ring-primary' : ''
                }`}
                onClick={() => handleSpotClick(spot)}
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold">{spot.name}</h3>
                  <span className="text-sm text-muted-foreground">⭐ {spot.rating}</span>
                </div>
                <div className="space-y-1 text-sm text-muted-foreground">
                  <div className="flex justify-between">
                    <span>Wave Height:</span>
                    <span className="font-medium text-foreground">{spot.waveHeight}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Wind Speed:</span>
                    <span className="font-medium text-foreground">{spot.windSpeed}</span>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Map */}
        <div className="flex-1 relative">
          <div ref={mapContainer} className="absolute inset-0" />
        </div>
      </div>
    </div>
  );
}