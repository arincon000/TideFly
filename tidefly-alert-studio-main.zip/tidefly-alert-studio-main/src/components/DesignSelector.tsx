import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface DesignOption {
  id: string;
  name: string;
  description: string;
  theme: string;
  colors: string[];
  features: string[];
}

interface DesignSelectorProps {
  onSelectDesign: (designId: string) => void;
}

export function DesignSelector({ onSelectDesign }: DesignSelectorProps) {
  const designs: DesignOption[] = [
    {
      id: "ocean-blue",
      name: "Ocean Blue",
      description: "Clean, modern design with ocean-inspired gradients",
      theme: "Professional & Trustworthy",
      colors: ["#2563eb", "#0891b2", "#06b6d4"],
      features: [
        "Ocean gradient backgrounds",
        "Clean typography",
        "Professional feel",
        "CodeFast-inspired layout",
        "Smooth animations"
      ]
    },
    {
      id: "sunset-vibes",
      name: "Sunset Vibes",
      description: "Warm, energetic design with sunset colors",
      theme: "Energetic & Creative",
      colors: ["#f97316", "#ef4444", "#f59e0b"],
      features: [
        "Warm sunset gradients",
        "Playful interactions",
        "Creative surf imagery",
        "Dynamic card designs",
        "Vibrant CTAs"
      ]
    },
    {
      id: "minimal-zen",
      name: "Minimal Zen",
      description: "Clean, minimalist design focusing on simplicity",
      theme: "Calm & Focused",
      colors: ["#475569", "#64748b", "#94a3b8"],
      features: [
        "Ultra-clean layouts",
        "Minimal color palette",
        "Focus on typography",
        "Zen-like spacing",
        "Subtle interactions"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-background py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-4">
            Choose Your TideFly Style
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Select the design that best represents your surf tracking experience. Each option offers a unique aesthetic while maintaining excellent functionality.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {designs.map((design, index) => (
            <Card 
              key={design.id}
              className="relative group hover:shadow-wave transition-all duration-300 cursor-pointer border-accent/20"
              onClick={() => onSelectDesign(design.id)}
            >
              {index === 0 && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-gradient-ocean text-white px-4 py-1">
                    Current
                  </Badge>
                </div>
              )}
              
              <CardHeader>
                <div className="flex items-center space-x-3 mb-3">
                  {design.colors.map((color, colorIndex) => (
                    <div 
                      key={colorIndex}
                      className="w-6 h-6 rounded-full border-2 border-white shadow-sm"
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
                <CardTitle className="text-2xl">{design.name}</CardTitle>
                <CardDescription className="text-base">{design.description}</CardDescription>
                <Badge variant="outline" className="w-fit">
                  {design.theme}
                </Badge>
              </CardHeader>

              <CardContent>
                <ul className="space-y-2 mb-6">
                  {design.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="text-sm text-muted-foreground flex items-center">
                      <div className="w-1.5 h-1.5 bg-accent rounded-full mr-3" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <Button 
                  className={`w-full ${
                    index === 0 
                      ? 'bg-gradient-ocean hover:opacity-90' 
                      : 'bg-gradient-ocean hover:opacity-90'
                  }`}
                  variant={index === 0 ? "default" : "outline"}
                >
                  {index === 0 ? 'Currently Active' : 'Select This Style'}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <p className="text-muted-foreground mb-4">
            🎨 Each design includes the complete TideFly experience with custom branding, animations, and user flows
          </p>
          <Button variant="outline" onClick={() => onSelectDesign('ocean-blue')}>
            Continue with Ocean Blue
          </Button>
        </div>
      </div>
    </div>
  );
}