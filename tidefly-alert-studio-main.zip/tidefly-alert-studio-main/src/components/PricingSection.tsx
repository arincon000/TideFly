import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Waves, Zap, Crown } from "lucide-react";
import { useState } from "react";

export function PricingSection() {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');

  const plans = [
    {
      name: "Wave Watcher",
      icon: Waves,
      description: "Perfect for casual surfers",
      monthlyPrice: 9,
      yearlyPrice: 90,
      features: [
        "3 surf spot alerts",
        "Basic wave forecasts",
        "Email notifications",
        "5-day forecast window",
        "Community support"
      ],
      buttonText: "Start watching",
      variant: "outline" as const
    },
    {
      name: "Surf Seeker",
      icon: Zap,
      description: "For dedicated wave hunters",
      monthlyPrice: 19,
      yearlyPrice: 190,
      features: [
        "Unlimited surf spot alerts",
        "Advanced wave & wind data",
        "SMS + Email notifications",
        "14-day forecast window",
        "Tide information",
        "Priority support"
      ],
      buttonText: "Start seeking",
      variant: "default" as const,
      popular: true
    },
    {
      name: "Pro Rider",
      icon: Crown,
      description: "For professional surfers",
      monthlyPrice: 39,
      yearlyPrice: 390,
      features: [
        "Everything in Surf Seeker",
        "Global spot monitoring",
        "Custom alert criteria",
        "API access",
        "Historical data analysis",
        "1-on-1 setup session"
      ],
      buttonText: "Go pro",
      variant: "outline" as const
    }
  ];

  return (
    <section id="pricing" className="py-20 lg:py-32 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
            Choose your wave hunting plan
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            From casual beach days to professional surf trips, we've got the perfect plan for every surfer.
          </p>

          {/* Billing toggle */}
          <div className="inline-flex items-center p-1 bg-muted rounded-lg">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                billingCycle === 'monthly'
                  ? 'bg-background text-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingCycle('yearly')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                billingCycle === 'yearly'
                  ? 'bg-background text-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Yearly
              <Badge variant="secondary" className="ml-2 bg-success text-success-foreground">
                Save 17%
              </Badge>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan) => {
            const Icon = plan.icon;
            const price = billingCycle === 'monthly' ? plan.monthlyPrice : plan.yearlyPrice;
            
            return (
              <Card 
                key={plan.name} 
                className={`relative ${
                  plan.popular 
                    ? 'border-accent shadow-wave scale-105' 
                    : 'border-border hover:border-accent/50'
                } transition-all duration-300 hover:shadow-subtle`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-gradient-ocean text-white px-4 py-1">
                      Most Popular
                    </Badge>
                  </div>
                )}
                
                <CardHeader className="text-center pb-4">
                  <div className={`w-12 h-12 mx-auto mb-4 rounded-xl flex items-center justify-center ${
                    plan.popular ? 'bg-gradient-ocean' : 'bg-accent/10'
                  }`}>
                    <Icon className={`w-6 h-6 ${plan.popular ? 'text-white' : 'text-accent'}`} />
                  </div>
                  <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
                  <CardDescription>{plan.description}</CardDescription>
                </CardHeader>

                <CardContent className="pt-0">
                  <div className="text-center mb-6">
                    <div className="flex items-baseline justify-center">
                      <span className="text-4xl font-bold text-foreground">${price}</span>
                      <span className="text-muted-foreground ml-1">
                        /{billingCycle === 'monthly' ? 'mo' : 'yr'}
                      </span>
                    </div>
                    {billingCycle === 'yearly' && (
                      <p className="text-sm text-muted-foreground mt-1">
                        ${(price / 12).toFixed(0)}/month billed annually
                      </p>
                    )}
                  </div>

                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <Check className="w-5 h-5 text-success mr-3 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-muted-foreground">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button 
                    className={`w-full ${
                      plan.popular 
                        ? 'bg-gradient-ocean hover:opacity-90' 
                        : ''
                    }`}
                    variant={plan.variant}
                    size="lg"
                  >
                    {plan.buttonText}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Trust indicators */}
        <div className="text-center mt-16">
          <p className="text-muted-foreground mb-4">Trusted by surfers worldwide</p>
          <div className="flex items-center justify-center space-x-8 opacity-60">
            {/* Placeholder for customer logos */}
            <div className="w-20 h-8 bg-muted rounded"></div>
            <div className="w-20 h-8 bg-muted rounded"></div>
            <div className="w-20 h-8 bg-muted rounded"></div>
            <div className="w-20 h-8 bg-muted rounded"></div>
          </div>
        </div>
      </div>
    </section>
  );
}