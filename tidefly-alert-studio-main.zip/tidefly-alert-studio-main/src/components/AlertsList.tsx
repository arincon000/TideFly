import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Clock, Waves, Wind, Pause, RotateCcw, Plus } from "lucide-react";

interface Alert {
  id: string;
  name: string;
  route: string;
  spot: string;
  window: string;
  lastChecked: string;
  price: string;
  status: 'active' | 'hit' | 'paused';
  conditions?: {
    wave?: string;
    wind?: string;
    ok?: number;
  };
}

interface AlertsListProps {
  onNewAlert: () => void;
  onExplore: () => void;
}

export function AlertsList({ onNewAlert, onExplore }: AlertsListProps) {
  const alerts: Alert[] = [
    {
      id: "1",
      name: "Surf Alert 2",
      route: "FCO → LIS",
      spot: "spot #7a583bc7-96e3-40b0-ab0b-0fb3189b8ed1",
      window: "window 5d",
      lastChecked: "2 hours ago",
      price: "€180.83",
      status: "hit",
      conditions: { ok: 4 }
    },
    {
      id: "2", 
      name: "Surf Alert",
      route: "LIS → BIQ",
      spot: "spot #15bbdb3e-504a-4c50-8d34-6450104c22b3",
      window: "window 5d",
      lastChecked: "2 hours ago",
      price: "€0",
      status: "active",
      conditions: { ok: 0 }
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'hit':
        return 'bg-success text-success-foreground';
      case 'active':
        return 'bg-accent text-accent-foreground';
      case 'paused':
        return 'bg-muted text-muted-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'hit':
        return 'Hit sent';
      case 'active':
        return 'No surf';
      case 'paused':
        return 'Paused';
      default:
        return status;
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Your alerts</h1>
          <p className="text-muted-foreground">
            Monitor and manage your surf condition alerts
          </p>
        </div>
        
        <div className="flex gap-3">
          <Button onClick={onExplore} variant="outline">
            <MapPin className="mr-2 h-4 w-4" />
            Explore Spots
          </Button>
          <Button onClick={onNewAlert} className="bg-gradient-ocean hover:opacity-90">
            <Plus className="w-4 h-4 mr-2" />
            New alert
          </Button>
        </div>
      </div>

      <div className="space-y-6">
        {alerts.map((alert) => (
          <Card key={alert.id} className="border-accent/20 shadow-subtle hover:shadow-wave transition-all duration-300">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <CardTitle className="text-xl">{alert.name}</CardTitle>
                    <Badge className={getStatusColor(alert.status)}>
                      {getStatusText(alert.status)}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                    <div className="flex items-center">
                      <MapPin className="w-4 h-4 mr-1 text-accent" />
                      {alert.route}
                    </div>
                    <div className="flex items-center">
                      <Waves className="w-4 h-4 mr-1 text-accent" />
                      {alert.spot}
                    </div>
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 mr-1 text-accent" />
                      {alert.window}
                    </div>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="text-2xl font-bold text-foreground mb-1">
                    {alert.price}
                  </div>
                  {alert.conditions && (
                    <div className="text-sm text-muted-foreground">
                      OK: {alert.conditions.ok}
                    </div>
                  )}
                </div>
              </div>
            </CardHeader>
            
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-sm text-muted-foreground">
                  Last checked: {alert.lastChecked}
                </div>
                
                <div className="flex space-x-3">
                  <Button variant="outline" size="sm">
                    <Pause className="w-4 h-4 mr-2" />
                    Pause
                  </Button>
                  <Button variant="outline" size="sm">
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Snooze 7d
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {alerts.length === 0 && (
        <div className="text-center py-16">
          <Waves className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-foreground mb-2">
            No alerts yet
          </h3>
          <p className="text-muted-foreground mb-6">
            Create your first surf alert to get notified about perfect conditions
          </p>
          <Button onClick={onNewAlert} className="bg-gradient-ocean hover:opacity-90">
            <Plus className="w-4 h-4 mr-2" />
            Create your first alert
          </Button>
        </div>
      )}
    </div>
  );
}