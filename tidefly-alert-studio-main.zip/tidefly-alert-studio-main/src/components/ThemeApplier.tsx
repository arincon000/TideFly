import { useEffect } from 'react';

interface ThemeApplierProps {
  theme: string;
  children: React.ReactNode;
}

const themeClasses = {
  'ocean-blue': '', // Default theme, no additional classes
  'sunset-vibes': 'theme-sunset',
  'minimal-zen': 'theme-minimal'
};

export function ThemeApplier({ theme, children }: ThemeApplierProps) {
  useEffect(() => {
    // Remove all theme classes first
    document.documentElement.classList.remove('theme-sunset', 'theme-minimal');
    
    // Apply the selected theme class
    const themeClass = themeClasses[theme as keyof typeof themeClasses];
    if (themeClass) {
      document.documentElement.classList.add(themeClass);
    }

    // Import theme-specific CSS
    if (theme === 'sunset-vibes') {
      import('../themes/sunset-vibes.css');
    } else if (theme === 'minimal-zen') {
      import('../themes/minimal-zen.css');
    }
  }, [theme]);

  return (
    <div className="animate-theme-transition">
      {children}
    </div>
  );
}