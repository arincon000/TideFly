import { Button } from "@/components/ui/button";
import { Play, ArrowRight } from "lucide-react";

export function Hero() {
  return (
    <section className="relative py-20 lg:py-32 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-hero opacity-5" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center">
          {/* Badge */}
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-accent/10 border border-accent/20 mb-8">
            <span className="text-sm font-medium text-accent-foreground">
              🏄‍♂️ Smart surf alerts for passionate surfers
            </span>
          </div>

          {/* Main heading */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-foreground mb-6 leading-tight">
            Never miss the perfect
            <span className="block bg-gradient-ocean bg-clip-text text-transparent">
              wave again
            </span>
          </h1>

          {/* Description */}
          <p className="text-xl md:text-2xl text-muted-foreground mb-12 max-w-3xl mx-auto leading-relaxed">
            Get intelligent surf alerts based on wave height, wind conditions, and your travel preferences. 
            TideFly monitors global surf conditions and notifies you when epic sessions await.
          </p>

          {/* CTA buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
            <Button 
              size="lg" 
              className="bg-gradient-ocean hover:opacity-90 transition-opacity shadow-ocean px-8 py-4 text-lg"
            >
              Start tracking waves
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="border-accent text-accent hover:bg-accent hover:text-accent-foreground px-8 py-4 text-lg"
            >
              <Play className="mr-2 h-5 w-5" />
              Watch demo
            </Button>
          </div>

          {/* Video placeholder */}
          <div className="relative max-w-4xl mx-auto">
            <div className="aspect-video bg-gradient-wave rounded-2xl shadow-wave border border-accent/20 flex items-center justify-center group cursor-pointer hover:shadow-ocean transition-all duration-500">
              <div className="text-center">
                <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mb-4 mx-auto group-hover:scale-110 transition-transform duration-300">
                  <Play className="w-8 h-8 text-white ml-1" />
                </div>
                <p className="text-white font-medium text-lg">
                  See how TideFly works
                </p>
                <p className="text-white/80 text-sm mt-1">
                  2 min demo video
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}