import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { MapPin, Waves, Wind, Clock, DollarSign, Calendar } from "lucide-react";
import { useState } from "react";

interface NewAlertFormProps {
  onBack: () => void;
}

export function NewAlertForm({ onBack }: NewAlertFormProps) {
  const [formData, setFormData] = useState({
    name: "",
    spot: "",
    origin: "",
    destination: "",
    forecastWindow: "5",
    minWave: "",
    maxWind: "",
    minNights: "",
    maxNights: "",
    maxPrice: "",
    daysMask: "all"
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Alert created:', formData);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <Button variant="ghost" onClick={onBack} className="mb-4">
          ← Back to alerts
        </Button>
        <h1 className="text-3xl font-bold text-foreground mb-2">Create new surf alert</h1>
        <p className="text-muted-foreground">
          Set up intelligent notifications for perfect surf conditions and travel deals
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Basic Info */}
        <Card className="border-accent/20 shadow-subtle">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Waves className="w-5 h-5 text-accent mr-2" />
              Alert Details
            </CardTitle>
            <CardDescription>
              Give your alert a name and select your target surf spot
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="name">Alert Name</Label>
                <Input
                  id="name"
                  placeholder="e.g., Pipeline Winter Sessions"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="border-accent/20 focus:border-accent"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="spot">Surf Spot</Label>
                <Select value={formData.spot} onValueChange={(value) => setFormData(prev => ({ ...prev, spot: value }))}>
                  <SelectTrigger className="border-accent/20 focus:border-accent">
                    <SelectValue placeholder="Select surf spot" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pipeline">Pipeline, Hawaii</SelectItem>
                    <SelectItem value="jeffreys-bay">Jeffreys Bay, South Africa</SelectItem>
                    <SelectItem value="gold-coast">Gold Coast, Australia</SelectItem>
                    <SelectItem value="ericeira">Ericeira, Portugal</SelectItem>
                    <SelectItem value="hossegor">Hossegor, France</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Travel Info */}
        <Card className="border-accent/20 shadow-subtle">
          <CardHeader>
            <CardTitle className="flex items-center">
              <MapPin className="w-5 h-5 text-accent mr-2" />
              Travel Preferences
            </CardTitle>
            <CardDescription>
              Configure your departure location and trip duration
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="origin">Origin Airport (IATA)</Label>
                <Input
                  id="origin"
                  placeholder="e.g., LAX"
                  value={formData.origin}
                  onChange={(e) => setFormData(prev => ({ ...prev, origin: e.target.value }))}
                  className="border-accent/20 focus:border-accent"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="destination">Destination Airport (IATA)</Label>
                <Input
                  id="destination"
                  placeholder="auto from spot"
                  value={formData.destination}
                  onChange={(e) => setFormData(prev => ({ ...prev, destination: e.target.value }))}
                  className="border-accent/20 focus:border-accent"
                />
              </div>
            </div>

            <Separator />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <Label htmlFor="minNights">Min Nights</Label>
                <Input
                  id="minNights"
                  type="number"
                  placeholder="2"
                  value={formData.minNights}
                  onChange={(e) => setFormData(prev => ({ ...prev, minNights: e.target.value }))}
                  className="border-accent/20 focus:border-accent"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="maxNights">Max Nights</Label>
                <Input
                  id="maxNights"
                  type="number"
                  placeholder="14"
                  value={formData.maxNights}
                  onChange={(e) => setFormData(prev => ({ ...prev, maxNights: e.target.value }))}
                  className="border-accent/20 focus:border-accent"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="maxPrice">Max Price (€)</Label>
                <Input
                  id="maxPrice"
                  type="number"
                  placeholder="800"
                  value={formData.maxPrice}
                  onChange={(e) => setFormData(prev => ({ ...prev, maxPrice: e.target.value }))}
                  className="border-accent/20 focus:border-accent"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Surf Conditions */}
        <Card className="border-accent/20 shadow-subtle">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Wind className="w-5 h-5 text-accent mr-2" />
              Surf Conditions
            </CardTitle>
            <CardDescription>
              Define your ideal wave and weather conditions
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <Label htmlFor="forecastWindow">Forecast Window (days)</Label>
                <Input
                  id="forecastWindow"
                  type="number"
                  placeholder="7"
                  value={formData.forecastWindow}
                  onChange={(e) => setFormData(prev => ({ ...prev, forecastWindow: e.target.value }))}
                  className="border-accent/20 focus:border-accent"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="minWave">Min Wave Height (m)</Label>
                <Input
                  id="minWave"
                  type="number"
                  step="0.1"
                  placeholder="1.2"
                  value={formData.minWave}
                  onChange={(e) => setFormData(prev => ({ ...prev, minWave: e.target.value }))}
                  className="border-accent/20 focus:border-accent"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="maxWind">Max Wind Speed (km/h)</Label>
                <Input
                  id="maxWind"
                  type="number"
                  placeholder="25"
                  value={formData.maxWind}
                  onChange={(e) => setFormData(prev => ({ ...prev, maxWind: e.target.value }))}
                  className="border-accent/20 focus:border-accent"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Days Preference</Label>
              <div className="flex flex-wrap gap-2">
                <Badge 
                  variant={formData.daysMask === "all" ? "default" : "outline"}
                  className="cursor-pointer hover:bg-accent"
                  onClick={() => setFormData(prev => ({ ...prev, daysMask: "all" }))}
                >
                  All days
                </Badge>
                <Badge 
                  variant={formData.daysMask === "weekends" ? "default" : "outline"}
                  className="cursor-pointer hover:bg-accent"
                  onClick={() => setFormData(prev => ({ ...prev, daysMask: "weekends" }))}
                >
                  Weekends only
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Submit */}
        <div className="flex justify-end space-x-4">
          <Button variant="outline" onClick={onBack}>
            Cancel
          </Button>
          <Button type="submit" className="bg-gradient-ocean hover:opacity-90 px-8">
            Create Alert
          </Button>
        </div>
      </form>
    </div>
  );
}