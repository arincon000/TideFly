import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronLeft, ChevronRight, Palette, Check } from "lucide-react";

interface ThemeSwitcherProps {
  currentTheme: string;
  onThemeChange: (theme: string) => void;
  onApplyTheme?: () => void;
}

const themes = [
  {
    id: "ocean-blue",
    name: "Ocean Blue",
    description: "Professional & Trustworthy",
    colors: ["#2563eb", "#0891b2", "#06b6d4"],
    emoji: "🌊"
  },
  {
    id: "sunset-vibes", 
    name: "Sunset Vibes",
    description: "Energetic & Creative",
    colors: ["#f97316", "#ef4444", "#f59e0b"],
    emoji: "🌅"
  },
  {
    id: "minimal-zen",
    name: "Minimal Zen", 
    description: "Calm & Focused",
    colors: ["#475569", "#64748b", "#94a3b8"],
    emoji: "🧘"
  }
];

export function ThemeSwitcher({ currentTheme, onThemeChange, onApplyTheme }: ThemeSwitcherProps) {
  const currentIndex = themes.findIndex(theme => theme.id === currentTheme);
  const currentThemeData = themes[currentIndex];

  const goToPrevious = () => {
    const prevIndex = currentIndex === 0 ? themes.length - 1 : currentIndex - 1;
    onThemeChange(themes[prevIndex].id);
  };

  const goToNext = () => {
    const nextIndex = currentIndex === themes.length - 1 ? 0 : currentIndex + 1;
    onThemeChange(themes[nextIndex].id);
  };

  return (
    <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50">
      <div className="bg-card/95 backdrop-blur-sm border border-border rounded-2xl shadow-wave p-4 animate-fade-in">
        <div className="flex items-center space-x-4">
          {/* Previous button */}
          <Button
            variant="outline"
            size="sm"
            onClick={goToPrevious}
            className="w-10 h-10 rounded-xl p-0 hover:scale-105 transition-transform"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>

          {/* Current theme info */}
          <div className="text-center min-w-[200px]">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <span className="text-2xl">{currentThemeData.emoji}</span>
              <div className="flex space-x-1">
                {currentThemeData.colors.map((color, index) => (
                  <div 
                    key={index}
                    className="w-3 h-3 rounded-full border border-white/50 shadow-sm"
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>
            <h3 className="font-semibold text-foreground text-lg">{currentThemeData.name}</h3>
            <p className="text-xs text-muted-foreground">{currentThemeData.description}</p>
            <div className="flex items-center justify-center space-x-1 mt-1">
              {themes.map((_, index) => (
                <div
                  key={index}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    index === currentIndex ? 'bg-accent scale-125' : 'bg-muted'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Next button */}
          <Button
            variant="outline"
            size="sm"
            onClick={goToNext}
            className="w-10 h-10 rounded-xl p-0 hover:scale-105 transition-transform"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>

        {/* Action buttons */}
        <div className="flex items-center justify-center space-x-2 mt-4 pt-3 border-t border-border">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onThemeChange('design-selector')}
            className="text-xs"
          >
            <Palette className="w-3 h-3 mr-1" />
            View All
          </Button>
          
          {onApplyTheme && (
            <Button
              size="sm"
              onClick={onApplyTheme}
              className="bg-gradient-ocean hover:opacity-90 text-xs"
            >
              <Check className="w-3 h-3 mr-1" />
              Use This Theme
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}