import { useState } from "react";
import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { PricingSection } from "@/components/PricingSection";
import { NewAlertForm } from "@/components/NewAlertForm";
import { AlertsList } from "@/components/AlertsList";
import { DesignSelector } from "@/components/DesignSelector";
import { ThemeSwitcher } from "@/components/ThemeSwitcher";
import { ThemeApplier } from "@/components/ThemeApplier";
import { Explore } from "@/components/Explore";

type AppState = 'landing' | 'dashboard' | 'new-alert' | 'design-selector' | 'explore';

const Index = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentView, setCurrentView] = useState<AppState>('landing');
  const [selectedTheme, setSelectedTheme] = useState('ocean-blue');
  const [showThemeSwitcher, setShowThemeSwitcher] = useState(true);

  const handleLogin = () => {
    setIsLoggedIn(true);
    setCurrentView('dashboard');
  };

  const handleSignOut = () => {
    setIsLoggedIn(false);
    setCurrentView('landing');
  };

  const handleNewAlert = () => {
    setCurrentView('new-alert');
  };

  const handleExplore = () => {
    setCurrentView('explore');
  };

  const handleBackToAlerts = () => {
    setCurrentView('dashboard');
  };

  const handleDesignSelect = (designId: string) => {
    if (designId === 'design-selector') {
      setCurrentView('design-selector');
      setShowThemeSwitcher(false);
    } else {
      setSelectedTheme(designId);
      setCurrentView('landing');
      setShowThemeSwitcher(true);
    }
  };

  const handleThemeChange = (themeId: string) => {
    if (themeId === 'design-selector') {
      setCurrentView('design-selector');
      setShowThemeSwitcher(false);
    } else {
      setSelectedTheme(themeId);
    }
  };

  const handleApplyTheme = () => {
    setShowThemeSwitcher(false);
    // Could show a toast here: "Theme applied successfully!"
  };

  if (currentView === 'design-selector') {
    return (
      <ThemeApplier theme={selectedTheme}>
        <DesignSelector onSelectDesign={handleDesignSelect} />
      </ThemeApplier>
    );
  }

  if (currentView === 'explore' && isLoggedIn) {
    return (
      <ThemeApplier theme={selectedTheme}>
        <Explore onBack={handleBackToAlerts} />
      </ThemeApplier>
    );
  }

  if (currentView === 'new-alert' && isLoggedIn) {
    return (
      <ThemeApplier theme={selectedTheme}>
        <Header isLoggedIn={isLoggedIn} onLoginClick={handleLogin} onSignOutClick={handleSignOut} />
        <NewAlertForm onBack={handleBackToAlerts} />
      </ThemeApplier>
    );
  }

  if (currentView === 'dashboard' && isLoggedIn) {
    return (
      <ThemeApplier theme={selectedTheme}>
        <Header isLoggedIn={isLoggedIn} onLoginClick={handleLogin} onSignOutClick={handleSignOut} />
        <AlertsList onNewAlert={handleNewAlert} onExplore={handleExplore} />
      </ThemeApplier>
    );
  }

  return (
    <ThemeApplier theme={selectedTheme}>
      <div className="min-h-screen bg-background">
        <Header isLoggedIn={isLoggedIn} onLoginClick={handleLogin} onSignOutClick={handleSignOut} />
        <main>
          <Hero />
          <PricingSection />
        </main>
        
        {/* Theme Switcher - Shows when browsing themes */}
        {showThemeSwitcher && (
          <ThemeSwitcher 
            currentTheme={selectedTheme}
            onThemeChange={handleThemeChange}
            onApplyTheme={handleApplyTheme}
          />
        )}
      </div>
    </ThemeApplier>
  );
};

export default Index;
